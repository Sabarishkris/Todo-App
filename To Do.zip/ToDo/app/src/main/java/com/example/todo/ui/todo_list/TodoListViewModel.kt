package com.example.todo.ui.todo_list

import android.util.Log
import androidx.compose.material3.Snackbar
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.todo.data.ToDo

import com.example.todo.data.TodoRepository
import com.example.todo.util.Route
import com.example.todo.util.UiEvents
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TodoListViewModel @Inject constructor(private val repository: TodoRepository) : ViewModel() {
    val todos = repository.getToDos()
    private val _uiEvents = Channel<UiEvents>()
    val uiEvents = _uiEvents.receiveAsFlow()
    private var deleteTodo: ToDo? = null
    fun onEvent(event: TodoListEvent) {
        when (event) {
            TodoListEvent.onAddTodoClicked ->
                onSendUiEvent(UiEvents.Navigate(Route.ADD_EDIT_TODO))

            is TodoListEvent.onDeleteTodo ->
                viewModelScope.launch {
                    deleteTodo = event.toDo
                    repository.delete(event.toDo)
                    onSendUiEvent(
                        UiEvents.ShowSnackbar(
                            message = "Todo deleted ",
                            action = "Undo"
                        )
                    )
                }

            is TodoListEvent.onDoneChange ->
                viewModelScope.launch {
                    repository.insert(
                        event.toDo.copy(
                            isDone = event.isDone
                        )
                    )
                }

            is TodoListEvent.onTodoClicked -> {
                Log.d("msg", "${event.toDo.id}")
                onSendUiEvent(UiEvents.Navigate(Route.ADD_EDIT_TODO + "?todoId=${event.toDo.id}"))
            }

            TodoListEvent.onUndoClicked ->
                deleteTodo?.let { todo ->
                    viewModelScope.launch {
                        repository.insert(todo)
                    }
                }

            else -> Unit
        }
    }

    private fun onSendUiEvent(events: UiEvents) {
        viewModelScope.launch {
            _uiEvents.send(events)
        }

    }
}