package com.example.todo.ui.add_edit_todo

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.todo.data.ToDo
import com.example.todo.data.TodoRepository
import com.example.todo.util.UiEvents
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddEditTodoViewModel @Inject constructor(
    private val repository: TodoRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    var todo by mutableStateOf<ToDo?>(null)
        private set
    var title by mutableStateOf("")
        private set
    var description by mutableStateOf("")
        private set
    private val _uiEvent = Channel<UiEvents>()
    val uiEvents = _uiEvent.receiveAsFlow()

    init {
        val todoId = savedStateHandle.get<Int>("todoId")
        Log.d("id", "$todoId")
        if (todoId != -1) {
            viewModelScope.launch {
                repository.getToDoById(todoId!!)?.let { todo ->
                    title = todo.name
                    description = todo.description ?: ""
                    this@AddEditTodoViewModel.todo = todo
                }

            }
        }
    }

    fun onEvent(event: AddEditTodoEvent) {
        when (event) {
            is AddEditTodoEvent.onDescriptionChange -> {
                description = event.description
            }

            AddEditTodoEvent.onSaveTodoClick -> {
                if (title.isBlank()) {
                    onSendUiEvent(
                        UiEvents.ShowSnackbar(
                            message = "The title can't be empty "
                        )
                    )
                    return
                }
                viewModelScope.launch {
                    repository.insert(
                        ToDo(
                            name = title,
                            description = description,
                            isDone = todo?.isDone ?: false,
                            id = todo?.id
                        )
                    )
                }
                onSendUiEvent(UiEvents.popBackStack)
            }

            is AddEditTodoEvent.onTitleChange -> {
                title = event.title
            }
        }
    }

    private fun onSendUiEvent(events: UiEvents) {
        viewModelScope.launch {
            _uiEvent.send(events)
        }

    }
}