package com.example.todo.ui.add_edit_todo

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.todo.util.UiEvents

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AddEditTodoScreen(
    onPopBackStack: () -> Unit,
    viewModel: AddEditTodoViewModel = hiltViewModel()
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add / Update Your Todo") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary),
                navigationIcon = {
                    IconButton(onClick = onPopBackStack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        }
    ) {innerpadding->
        val scaffoldState = remember { SnackbarHostState() }
        LaunchedEffect(key1 = true) {
            viewModel.uiEvents.collect { event ->
                when (event) {
                    is UiEvents.ShowSnackbar -> {
                        scaffoldState.showSnackbar(
                            message = event.message,
                            actionLabel = event.action
                        )
                    }

                    UiEvents.popBackStack -> onPopBackStack()
                    else -> Unit
                }
            }

        }
        Scaffold(snackbarHost = { SnackbarHost(scaffoldState) },
            modifier = Modifier
                .padding(innerpadding)
                .fillMaxSize()
                .padding(16.dp),
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    viewModel.onEvent(
                        AddEditTodoEvent.onSaveTodoClick
                    )
                }) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = "Save")

                }
            }
        ) {
            Column(modifier = Modifier
                .padding(innerpadding)
                .fillMaxSize()) {
                OutlinedTextField(
                    value = viewModel.title,
                    onValueChange = { viewModel.onEvent(AddEditTodoEvent.onTitleChange(it)) },
                    placeholder = { Text(text = "Title") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = viewModel.description,
                    onValueChange = { viewModel.onEvent(AddEditTodoEvent.onDescriptionChange(it)) },
                    placeholder = { Text(text = "Description") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = false,
                    maxLines = 5
                )

            }

        }
    }
}