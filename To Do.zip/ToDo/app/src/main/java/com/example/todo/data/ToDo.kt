package com.example.todo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class ToDo(

    var name :String,
    var description:String,
    var isDone:Boolean,
    @PrimaryKey
    var id:Int?=null,
)
