package com.example.todo.ui.add_edit_todo

import android.icu.text.CaseMap.Title

sealed class AddEditTodoEvent {
    data class onTitleChange(val title: String) : AddEditTodoEvent()
    data class onDescriptionChange(val description: String) : AddEditTodoEvent()
    object onSaveTodoClick : AddEditTodoEvent()
}