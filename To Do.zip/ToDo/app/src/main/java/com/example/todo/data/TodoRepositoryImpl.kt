package com.example.todo.data

import kotlinx.coroutines.flow.Flow

class TodoRepositoryImpl(private val dao: ToDoDao):TodoRepository {
    override suspend fun insert(toDo: ToDo) {
       dao.insert(toDo)
    }

    override suspend fun delete(toDo: ToDo) {
      dao.delete(toDo)
    }

    override suspend fun getToDoById(id: Int): ToDo? {
        return dao.getToDoById(id)
    }

    override fun getToDos(): Flow<List<ToDo>> {
     return dao.getToDos()
    }
}