package com.example.todo.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ToDoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(toDo: ToDo)
    @Delete
    suspend  fun delete(toDo: ToDo)
    @Query("Select * from todo where id=:id")
    suspend fun getToDoById(id:Int):ToDo?
    @Query("select * from todo")
     fun getToDos():Flow<List<ToDo>>
}