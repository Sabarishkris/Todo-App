package com.example.todo.data

import kotlinx.coroutines.flow.Flow

interface TodoRepository {

    suspend fun insert(toDo: ToDo)

    suspend fun delete(toDo: ToDo)

    suspend fun getToDoById(id:Int):ToDo?

    fun getToDos(): Flow<List<ToDo>>
}