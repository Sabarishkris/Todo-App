package com.example.todo.ui.todo_list

import com.example.todo.data.ToDo

sealed class TodoListEvent {
    data class onDeleteTodo(val toDo: ToDo) : TodoListEvent()
    data class onDoneChange(val toDo: ToDo, val isDone: Boolean) : TodoListEvent()
    object onUndoClicked : TodoListEvent()
    data class onTodoClicked(val toDo: ToDo) : TodoListEvent()
    object onAddTodoClicked : TodoListEvent()
}