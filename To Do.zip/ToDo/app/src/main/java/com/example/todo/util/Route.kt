package com.example.todo.util

object Route {
    const val SPLASH="Splash"
    const val TODO_LIST="todo_list"
    const val ADD_EDIT_TODO="add_edit_todo"
}